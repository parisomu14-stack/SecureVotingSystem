# Secure Voting System

> ⚠️ **Educational / college project prototype.** Built for learning full-stack
> development and security practices. It is **not** suitable for a real
> government election without independent security auditing and additional
> election-grade requirements (e.g. voter identity verification, paper trail,
> election-commission oversight, etc.).

A full-stack, JWT-secured voting application: Spring Boot REST API backend,
a plain HTML/CSS/JS frontend, a MySQL database, and one-click Excel export
of results (Apache POI).

---

## Folder structure

```
SecureVotingSystem/
├── backend/     Spring Boot API (Java 17, Maven, MySQL, JWT, BCrypt, Excel export)
├── frontend/    HTML/CSS/JS pages (served automatically by the backend)
├── database/    schema.sql, data.sql, and setup notes
├── excel/       Generated voting_results.xlsx lands here
├── run.sh       Linux/macOS launcher
├── run.bat      Windows launcher
└── README.md    This file
```

---

## 1. Prerequisites

Install these once:

1. **Java 17 or newer** — https://adoptium.net/
2. **Maven** — https://maven.apache.org/download.cgi
3. **MySQL 8+** — https://dev.mysql.com/downloads/

Check they're on your PATH:
```bash
java -version
mvn -version
mysql --version
```

## 2. Create the database

```bash
mysql -u root -p -e "CREATE DATABASE secure_voting_db;"
```

(Or just run `database/schema.sql` — see `database/README.md` for both options.)

## 3. Configure database username/password and JWT secret

Open `backend/src/main/resources/application.properties`. Either edit the
defaults directly, **or** (recommended) set environment variables before
running so nothing sensitive lives in the source code:

```bash
export DB_USERNAME=root
export DB_PASSWORD=your_mysql_password
export JWT_SECRET=some-long-random-string-at-least-32-characters
```

On Windows (PowerShell):
```powershell
$env:DB_USERNAME="root"
$env:DB_PASSWORD="your_mysql_password"
$env:JWT_SECRET="some-long-random-string-at-least-32-characters"
```

## 4. (Optional) Run the SQL scripts

```bash
mysql -u root -p secure_voting_db < database/schema.sql
mysql -u root -p secure_voting_db < database/data.sql
```

This isn't strictly required — the app also auto-creates the tables on
startup — but it gives you 4 sample candidates immediately.

## 5. Start the backend (this also serves the frontend)

**Select the `SecureVotingSystem` folder in your terminal/IDE and run:**

- **Windows:** double-click `run.bat`, or run it from a terminal
- **Linux/macOS:**
  ```bash
  chmod +x run.sh
  ./run.sh
  ```

Either script runs `mvn spring-boot:run` inside `backend/`. The Maven build
automatically copies everything from `frontend/` into the backend's static
resources, so the whole app is served from one place.

(You can also run it manually: `cd backend && mvn spring-boot:run`)

## 6. Open the app

Go to **http://localhost:8080/** in your browser.

- **Register** a voter account, or
- **Login** with the auto-created admin account:
  - Email: `admin@voting.local`
  - Password: `Admin@123`
  - **Change this password immediately** (or set `ADMIN_PASSWORD` before
    first startup) — it's a well-known default otherwise.

## 7. Vote

Log in as a voter → **Vote** page → pick a candidate → confirm → done.
A voter can only vote once; this is enforced both by the backend logic and
by a database-level unique constraint, so it holds even under concurrent
requests.

## 8. Check results

Anyone can view **Results** (`result.html`) — live vote counts per candidate.

## 9. Admin dashboard

Log in as admin → redirected to the **Admin Dashboard**:
- Add / edit / delete candidates
- View total votes per candidate
- Export results to Excel

## 10. Export to Excel

From the admin dashboard, click **"Export Results to Excel"**. The backend
generates `excel/voting_results.xlsx` (created automatically if it doesn't
exist yet) with a "Results" sheet and an "Election Summary" sheet, and your
browser downloads it.

---

## API reference

| Method | Endpoint                       | Access        |
|--------|---------------------------------|---------------|
| POST   | `/api/auth/register`             | Public        |
| POST   | `/api/auth/login`                | Public        |
| GET    | `/api/candidates`                 | Public        |
| GET    | `/api/candidates/{id}`            | Public        |
| POST   | `/api/votes`                      | Authenticated |
| GET    | `/api/votes/status`               | Authenticated |
| GET    | `/api/results`                    | Public        |
| POST   | `/api/admin/candidates`           | Admin only    |
| PUT    | `/api/admin/candidates/{id}`      | Admin only    |
| DELETE | `/api/admin/candidates/{id}`      | Admin only    |
| GET    | `/api/admin/votes`                | Admin only    |
| GET    | `/api/admin/export/excel`         | Admin only    |

All responses share the shape:
```json
{ "success": true, "message": "...", "data": { } }
```

## Security notes

- Passwords: BCrypt (never stored in plain text)
- Auth: stateless JWT (`Authorization: Bearer <token>`)
- Duplicate voting: blocked by (1) an application-level check and (2) a
  `UNIQUE` constraint on `votes.voter_id`, so it holds even under a race
  between two simultaneous requests
- Voter identity for a vote always comes from the validated JWT, never from
  the request body — a voter cannot spoof another user's vote
- Admin endpoints require `ROLE_ADMIN` via Spring Security
- Global exception handling never leaks stack traces or raw database errors
- CORS is restricted to `localhost`/`127.0.0.1` origins
- No secrets are hard-coded — DB credentials and the JWT secret are read
  from environment variables (with local-dev fallbacks in
  `application.properties`)

## Running the backend tests

```bash
cd backend
mvn test
```

Covers: registration, login (valid/invalid), public candidate retrieval,
casting a vote, duplicate-vote prevention, unauthorized vote attempts,
admin-only authorization, and Excel export — using an in-memory H2 database
so your real MySQL data is never touched.

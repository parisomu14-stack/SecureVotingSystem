package com.example.voting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecureVotingApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecureVotingApplication.class, args);
        System.out.println("\nSecure Voting System is running at: http://localhost:8080/\n");
    }
}

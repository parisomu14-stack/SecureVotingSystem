package com.example.voting.config;

import com.example.voting.entity.Role;
import com.example.voting.entity.User;
import com.example.voting.repository.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    public CommandLineRunner seedAdmin(UserRepository userRepository,
                                        PasswordEncoder passwordEncoder,
                                        @Value("${app.admin.default-email}") String adminEmail,
                                        @Value("${app.admin.default-password}") String adminPassword) {
        return args -> {
            if (!userRepository.existsByRole(Role.ROLE_ADMIN)) {
                User admin = User.builder()
                        .name("Election Administrator")
                        .email(adminEmail)
                        .passwordHash(passwordEncoder.encode(adminPassword))
                        .role(Role.ROLE_ADMIN)
                        .hasVoted(false)
                        .build();
                userRepository.save(admin);
                System.out.println("======================================================");
                System.out.println(" Default admin account created:");
                System.out.println(" Email:    " + adminEmail);
                System.out.println(" Password: " + adminPassword);
                System.out.println(" IMPORTANT: change this password after first login.");
                System.out.println("======================================================");
            }
        };
    }
}

package com.example.voting.controller;

import com.example.voting.dto.ApiResponse;
import com.example.voting.dto.CandidateDto;
import com.example.voting.entity.Vote;
import com.example.voting.service.CandidateService;
import com.example.voting.service.ExcelExportService;
import com.example.voting.service.VoteService;
import jakarta.validation.Valid;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;
import java.util.List;

// Every endpoint here is restricted to ROLE_ADMIN by SecurityConfig
// (requestMatchers("/api/admin/**").hasAuthority("ROLE_ADMIN")).
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final CandidateService candidateService;
    private final VoteService voteService;
    private final ExcelExportService excelExportService;

    public AdminController(CandidateService candidateService, VoteService voteService,
                            ExcelExportService excelExportService) {
        this.candidateService = candidateService;
        this.voteService = voteService;
        this.excelExportService = excelExportService;
    }

    @PostMapping("/candidates")
    public ApiResponse<CandidateDto> addCandidate(@Valid @RequestBody CandidateDto dto) {
        return ApiResponse.ok("Candidate added.", candidateService.addCandidate(dto));
    }

    @PutMapping("/candidates/{id}")
    public ApiResponse<CandidateDto> updateCandidate(@PathVariable Long id, @Valid @RequestBody CandidateDto dto) {
        return ApiResponse.ok("Candidate updated.", candidateService.updateCandidate(id, dto));
    }

    @DeleteMapping("/candidates/{id}")
    public ApiResponse<Void> deleteCandidate(@PathVariable Long id) {
        candidateService.deleteCandidate(id);
        return ApiResponse.ok("Candidate deleted.");
    }

    @GetMapping("/votes")
    public ApiResponse<List<Vote>> getAllVotes() {
        // Only aggregate vote records (voter id / candidate id / timestamp)
        // are exposed here - no voter names/emails, to avoid exposing
        // unnecessary personal voting information even to admins.
        return ApiResponse.ok("Votes fetched.", voteService.getAllVotes());
    }

    @GetMapping("/export/excel")
    public ResponseEntity<Resource> exportExcel() throws IOException {
        File file = excelExportService.exportResultsToExcel();
        Resource resource = new FileSystemResource(file);

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"voting_results.xlsx\"")
                .body(resource);
    }
}

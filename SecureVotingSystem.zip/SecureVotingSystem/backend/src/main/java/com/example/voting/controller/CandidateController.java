package com.example.voting.controller;

import com.example.voting.dto.ApiResponse;
import com.example.voting.dto.CandidateDto;
import com.example.voting.service.CandidateService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/candidates")
public class CandidateController {

    private final CandidateService candidateService;

    public CandidateController(CandidateService candidateService) {
        this.candidateService = candidateService;
    }

    @GetMapping
    public ApiResponse<List<CandidateDto>> getAllCandidates() {
        return ApiResponse.ok("Candidates fetched.", candidateService.getAllCandidates());
    }

    @GetMapping("/{id}")
    public ApiResponse<CandidateDto> getCandidateById(@PathVariable Long id) {
        return ApiResponse.ok("Candidate fetched.", candidateService.getCandidateById(id));
    }
}

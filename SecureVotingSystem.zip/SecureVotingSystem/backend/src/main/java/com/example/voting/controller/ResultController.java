package com.example.voting.controller;

import com.example.voting.dto.ApiResponse;
import com.example.voting.dto.ResultDto;
import com.example.voting.service.VoteService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/results")
public class ResultController {

    private final VoteService voteService;

    public ResultController(VoteService voteService) {
        this.voteService = voteService;
    }

    @GetMapping
    public ApiResponse<List<ResultDto>> getResults() {
        return ApiResponse.ok("Results fetched.", voteService.getResults());
    }
}

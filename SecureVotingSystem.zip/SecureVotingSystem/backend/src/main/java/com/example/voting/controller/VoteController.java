package com.example.voting.controller;

import com.example.voting.dto.*;
import com.example.voting.security.AuthUserPrincipal;
import com.example.voting.service.VoteService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/votes")
public class VoteController {

    private final VoteService voteService;

    public VoteController(VoteService voteService) {
        this.voteService = voteService;
    }

    @PostMapping
    public ApiResponse<ResultDto> castVote(@Valid @RequestBody VoteRequest request, Authentication authentication) {
        // The voter's identity comes ONLY from the validated JWT
        // (never from the request body), so a voter can never cast a
        // vote "as" someone else.
        AuthUserPrincipal principal = (AuthUserPrincipal) authentication.getPrincipal();
        ResultDto result = voteService.castVote(principal.getUserId(), request.getCandidateId());
        return ApiResponse.ok("Your vote has been recorded successfully.", result);
    }

    @GetMapping("/status")
    public ApiResponse<VoteStatusResponse> getVoteStatus(Authentication authentication) {
        AuthUserPrincipal principal = (AuthUserPrincipal) authentication.getPrincipal();
        return ApiResponse.ok("Vote status fetched.", voteService.getVoteStatus(principal.getUserId()));
    }
}

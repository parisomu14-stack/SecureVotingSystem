package com.example.voting.dto;

import lombok.*;

// Never include the password hash here - only non-sensitive fields
// are exposed to the frontend.
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthResponse {
    private String token;
    private Long userId;
    private String name;
    private String email;
    private String role;
    private boolean hasVoted;
}

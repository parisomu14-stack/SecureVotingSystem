package com.example.voting.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CandidateDto {
    private Long id;

    @NotBlank(message = "Candidate name is required")
    private String name;

    @NotBlank(message = "Party is required")
    private String party;

    private String symbol;
    private String description;
}

package com.example.voting.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ResultDto {
    private Long candidateId;
    private String candidateName;
    private String party;
    private long totalVotes;
}

package com.example.voting.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VoteStatusResponse {
    private boolean hasVoted;
    private Long votedCandidateId;
}

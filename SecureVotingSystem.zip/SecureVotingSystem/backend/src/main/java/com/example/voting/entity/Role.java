package com.example.voting.entity;

public enum Role {
    ROLE_VOTER,
    ROLE_ADMIN
}

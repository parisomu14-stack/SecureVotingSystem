package com.example.voting.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

// One row per cast vote. The unique constraint on voter_id is the
// database-level guarantee (in addition to the application-level
// transactional check) that a voter can never cast more than one vote,
// even under concurrent requests.
@Entity
@Table(name = "votes", uniqueConstraints = @UniqueConstraint(name = "uk_voter_single_vote", columnNames = "voter_id"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Vote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "voter_id", nullable = false)
    private Long voterId;

    @Column(name = "candidate_id", nullable = false)
    private Long candidateId;

    @Column(name = "voted_at", nullable = false, updatable = false)
    private LocalDateTime votedAt;

    @PrePersist
    protected void onCreate() {
        this.votedAt = LocalDateTime.now();
    }
}

package com.example.voting.repository;

import com.example.voting.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);
    boolean existsByRole(com.example.voting.entity.Role role);
    long countByRole(com.example.voting.entity.Role role);
}

package com.example.voting.repository;

import com.example.voting.entity.Vote;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface VoteRepository extends JpaRepository<Vote, Long> {
    Optional<Vote> findByVoterId(Long voterId);
    boolean existsByVoterId(Long voterId);
    long countByCandidateId(Long candidateId);
    List<Vote> findAll();
}

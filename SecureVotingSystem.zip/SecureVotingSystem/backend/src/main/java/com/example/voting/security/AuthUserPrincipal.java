package com.example.voting.security;

import lombok.*;

// Lightweight authenticated-user context extracted from the JWT and
// placed into the SecurityContext for controllers/services to read via
// SecurityContextHolder, instead of trusting any client-supplied id.
@Getter
@AllArgsConstructor
public class AuthUserPrincipal {
    private final Long userId;
    private final String email;
    private final String role;
}

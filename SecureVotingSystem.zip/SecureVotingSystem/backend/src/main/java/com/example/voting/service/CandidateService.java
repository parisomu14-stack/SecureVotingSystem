package com.example.voting.service;

import com.example.voting.dto.CandidateDto;
import com.example.voting.entity.Candidate;
import com.example.voting.exception.ResourceNotFoundException;
import com.example.voting.repository.CandidateRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CandidateService {

    private final CandidateRepository candidateRepository;

    public CandidateService(CandidateRepository candidateRepository) {
        this.candidateRepository = candidateRepository;
    }

    public List<CandidateDto> getAllCandidates() {
        return candidateRepository.findAll().stream().map(this::toDto).toList();
    }

    public CandidateDto getCandidateById(Long id) {
        Candidate candidate = candidateRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found."));
        return toDto(candidate);
    }

    @Transactional
    public CandidateDto addCandidate(CandidateDto dto) {
        Candidate candidate = Candidate.builder()
                .name(dto.getName().trim())
                .party(dto.getParty().trim())
                .symbol(dto.getSymbol())
                .description(dto.getDescription())
                .build();
        return toDto(candidateRepository.save(candidate));
    }

    @Transactional
    public CandidateDto updateCandidate(Long id, CandidateDto dto) {
        Candidate candidate = candidateRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found."));
        candidate.setName(dto.getName().trim());
        candidate.setParty(dto.getParty().trim());
        candidate.setSymbol(dto.getSymbol());
        candidate.setDescription(dto.getDescription());
        return toDto(candidateRepository.save(candidate));
    }

    @Transactional
    public void deleteCandidate(Long id) {
        if (!candidateRepository.existsById(id)) {
            throw new ResourceNotFoundException("Candidate not found.");
        }
        candidateRepository.deleteById(id);
    }

    private CandidateDto toDto(Candidate candidate) {
        return CandidateDto.builder()
                .id(candidate.getId())
                .name(candidate.getName())
                .party(candidate.getParty())
                .symbol(candidate.getSymbol())
                .description(candidate.getDescription())
                .build();
    }
}

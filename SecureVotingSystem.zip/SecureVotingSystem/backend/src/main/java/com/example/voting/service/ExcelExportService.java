package com.example.voting.service;

import com.example.voting.dto.ResultDto;
import com.example.voting.entity.Role;
import com.example.voting.repository.CandidateRepository;
import com.example.voting.repository.UserRepository;
import com.example.voting.repository.VoteRepository;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

// Generates excel/voting_results.xlsx using Apache POI whenever the
// admin requests an export. The file (and its parent folder) is created
// automatically if it does not already exist.
@Service
public class ExcelExportService {

    private final VoteService voteService;
    private final UserRepository userRepository;
    private final VoteRepository voteRepository;
    private final CandidateRepository candidateRepository;
    private final String outputPath;

    public ExcelExportService(VoteService voteService,
                               UserRepository userRepository,
                               VoteRepository voteRepository,
                               CandidateRepository candidateRepository,
                               @Value("${app.excel.output-path}") String outputPath) {
        this.voteService = voteService;
        this.userRepository = userRepository;
        this.voteRepository = voteRepository;
        this.candidateRepository = candidateRepository;
        this.outputPath = outputPath;
    }

    public File exportResultsToExcel() throws IOException {
        List<ResultDto> results = voteService.getResults();

        long totalRegisteredVoters = userRepository.countByRole(Role.ROLE_VOTER);
        long totalVotes = voteRepository.count();
        long totalCandidates = candidateRepository.count();
        double votingPercentage = totalRegisteredVoters == 0
                ? 0.0
                : (totalVotes * 100.0) / totalRegisteredVoters;

        try (Workbook workbook = new XSSFWorkbook()) {
            CellStyle headerStyle = buildHeaderStyle(workbook);

            buildResultsSheet(workbook, headerStyle, results);
            buildSummarySheet(workbook, headerStyle, totalRegisteredVoters, totalVotes, totalCandidates, votingPercentage);

            File outputFile = new File(outputPath);
            File parentDir = outputFile.getParentFile();
            if (parentDir != null && !parentDir.exists()) {
                parentDir.mkdirs();
            }

            try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                workbook.write(fos);
            }
            return outputFile;
        }
    }

    private void buildResultsSheet(Workbook workbook, CellStyle headerStyle, List<ResultDto> results) {
        Sheet sheet = workbook.createSheet("Results");
        String[] headers = {"Candidate ID", "Candidate Name", "Party", "Total Votes", "Exported Date/Time"};

        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }

        String exportedAt = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        int rowIdx = 1;
        for (ResultDto result : results) {
            Row row = sheet.createRow(rowIdx++);
            row.createCell(0).setCellValue(result.getCandidateId());
            row.createCell(1).setCellValue(result.getCandidateName());
            row.createCell(2).setCellValue(result.getParty());
            row.createCell(3).setCellValue(result.getTotalVotes());
            row.createCell(4).setCellValue(exportedAt);
        }

        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    private void buildSummarySheet(Workbook workbook, CellStyle headerStyle, long totalRegisteredVoters,
                                    long totalVotes, long totalCandidates, double votingPercentage) {
        Sheet sheet = workbook.createSheet("Election Summary");

        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Metric");
        headerRow.createCell(1).setCellValue("Value");
        headerRow.getCell(0).setCellStyle(headerStyle);
        headerRow.getCell(1).setCellStyle(headerStyle);

        Object[][] summaryRows = {
                {"Total Registered Voters", totalRegisteredVoters},
                {"Total Votes Cast", totalVotes},
                {"Total Candidates", totalCandidates},
                {"Voting Percentage", String.format("%.2f%%", votingPercentage)}
        };

        int rowIdx = 1;
        for (Object[] entry : summaryRows) {
            Row row = sheet.createRow(rowIdx++);
            row.createCell(0).setCellValue((String) entry[0]);
            if (entry[1] instanceof String s) {
                row.createCell(1).setCellValue(s);
            } else {
                row.createCell(1).setCellValue(((Number) entry[1]).doubleValue());
            }
        }

        sheet.autoSizeColumn(0);
        sheet.autoSizeColumn(1);
    }

    private CellStyle buildHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        return style;
    }
}

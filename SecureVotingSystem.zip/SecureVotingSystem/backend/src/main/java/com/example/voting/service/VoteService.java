package com.example.voting.service;

import com.example.voting.dto.ResultDto;
import com.example.voting.dto.VoteStatusResponse;
import com.example.voting.entity.Candidate;
import com.example.voting.entity.User;
import com.example.voting.entity.Vote;
import com.example.voting.exception.DuplicateVoteException;
import com.example.voting.exception.ResourceNotFoundException;
import com.example.voting.repository.CandidateRepository;
import com.example.voting.repository.UserRepository;
import com.example.voting.repository.VoteRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class VoteService {

    private final VoteRepository voteRepository;
    private final UserRepository userRepository;
    private final CandidateRepository candidateRepository;

    public VoteService(VoteRepository voteRepository, UserRepository userRepository,
                        CandidateRepository candidateRepository) {
        this.voteRepository = voteRepository;
        this.userRepository = userRepository;
        this.candidateRepository = candidateRepository;
    }

    // Everything below runs in a single database transaction. Two layers
    // guard against a voter casting more than one vote:
    //   1) An explicit existsByVoterId() check before doing anything else.
    //   2) A UNIQUE constraint on votes.voter_id at the database level,
    //      which will reject a second insert even if two requests from
    //      the same voter race past check #1 simultaneously. That race
    //      is caught below and turned into the same friendly error.
    @Transactional(isolation = Isolation.READ_COMMITTED)
    public ResultDto castVote(Long voterId, Long candidateId) {
        User voter = userRepository.findById(voterId)
                .orElseThrow(() -> new ResourceNotFoundException("Voter account not found."));

        if (voter.isHasVoted() || voteRepository.existsByVoterId(voterId)) {
            throw new DuplicateVoteException("You have already voted. Duplicate voting is not allowed.");
        }

        Candidate candidate = candidateRepository.findById(candidateId)
                .orElseThrow(() -> new ResourceNotFoundException("Selected candidate does not exist."));

        Vote vote = Vote.builder()
                .voterId(voterId)
                .candidateId(candidateId)
                .build();

        try {
            voteRepository.saveAndFlush(vote);
        } catch (DataIntegrityViolationException e) {
            // The unique constraint on voter_id tripped - a concurrent
            // request for the same voter got there first.
            throw new DuplicateVoteException("You have already voted. Duplicate voting is not allowed.");
        }

        voter.setHasVoted(true);
        userRepository.save(voter);

        long totalVotes = voteRepository.countByCandidateId(candidateId);

        return ResultDto.builder()
                .candidateId(candidate.getId())
                .candidateName(candidate.getName())
                .party(candidate.getParty())
                .totalVotes(totalVotes)
                .build();
    }

    public VoteStatusResponse getVoteStatus(Long voterId) {
        User voter = userRepository.findById(voterId)
                .orElseThrow(() -> new ResourceNotFoundException("Voter account not found."));

        Long votedCandidateId = voteRepository.findByVoterId(voterId)
                .map(Vote::getCandidateId)
                .orElse(null);

        return VoteStatusResponse.builder()
                .hasVoted(voter.isHasVoted())
                .votedCandidateId(votedCandidateId)
                .build();
    }

    public List<Vote> getAllVotes() {
        return voteRepository.findAll();
    }

    public List<ResultDto> getResults() {
        List<Candidate> candidates = candidateRepository.findAll();
        return candidates.stream()
                .map(c -> ResultDto.builder()
                        .candidateId(c.getId())
                        .candidateName(c.getName())
                        .party(c.getParty())
                        .totalVotes(voteRepository.countByCandidateId(c.getId()))
                        .build())
                .sorted((a, b) -> Long.compare(b.getTotalVotes(), a.getTotalVotes()))
                .toList();
    }
}

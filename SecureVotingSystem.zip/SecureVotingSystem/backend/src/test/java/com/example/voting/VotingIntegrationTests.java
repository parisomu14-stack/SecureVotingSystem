package com.example.voting;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * End-to-end tests covering the main required scenarios:
 * registration, login (valid/invalid), candidate retrieval,
 * successful vote, duplicate vote prevention, unauthorized vote
 * requests, admin authorization, and Excel export.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@ActiveProfiles("test")
class VotingIntegrationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private String registerAndLogin(String name, String email, String password) throws Exception {
        String registerBody = objectMapper.writeValueAsString(new java.util.HashMap<>() {{
            put("name", name);
            put("email", email);
            put("password", password);
            put("confirmPassword", password);
        }});

        String response = mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(registerBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andReturn().getResponse().getContentAsString();

        JsonNode node = objectMapper.readTree(response);
        return node.get("data").get("token").asText();
    }

    private String loginAsAdmin() throws Exception {
        String loginBody = objectMapper.writeValueAsString(new java.util.HashMap<>() {{
            put("email", "admin@voting.local");
            put("password", "Admin@123Test");
        }});

        String response = mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(loginBody))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();

        return objectMapper.readTree(response).get("data").get("token").asText();
    }

    private Long addCandidateAsAdmin(String adminToken, String name, String party) throws Exception {
        String body = objectMapper.writeValueAsString(new java.util.HashMap<>() {{
            put("name", name);
            put("party", party);
            put("symbol", "star");
            put("description", "Test candidate");
        }});

        String response = mockMvc.perform(post("/api/admin/candidates")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();

        return objectMapper.readTree(response).get("data").get("id").asLong();
    }

    @Test
    void registerAndLoginSucceed() throws Exception {
        String email = "voter1@example.com";
        String token = registerAndLogin("Voter One", email, "SecurePass1");
        org.junit.jupiter.api.Assertions.assertNotNull(token);
    }

    @Test
    void loginWithWrongPasswordFails() throws Exception {
        registerAndLogin("Voter Two", "voter2@example.com", "SecurePass1");

        String loginBody = objectMapper.writeValueAsString(new java.util.HashMap<>() {{
            put("email", "voter2@example.com");
            put("password", "WrongPassword");
        }});

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(loginBody))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.success").value(false));
    }

    @Test
    void candidateListIsPubliclyReadable() throws Exception {
        String adminToken = loginAsAdmin();
        addCandidateAsAdmin(adminToken, "Candidate A", "Party A");

        mockMvc.perform(get("/api/candidates"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    void voteWithoutTokenIsRejected() throws Exception {
        String adminToken = loginAsAdmin();
        Long candidateId = addCandidateAsAdmin(adminToken, "Candidate B", "Party B");

        String voteBody = objectMapper.writeValueAsString(new java.util.HashMap<>() {{
            put("candidateId", candidateId);
        }});

        mockMvc.perform(post("/api/votes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(voteBody))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void successfulVoteAndDuplicateVoteIsBlocked() throws Exception {
        String adminToken = loginAsAdmin();
        Long candidateId = addCandidateAsAdmin(adminToken, "Candidate C", "Party C");

        String voterToken = registerAndLogin("Voter Three", "voter3@example.com", "SecurePass1");

        String voteBody = objectMapper.writeValueAsString(new java.util.HashMap<>() {{
            put("candidateId", candidateId);
        }});

        // First vote should succeed.
        mockMvc.perform(post("/api/votes")
                        .header("Authorization", "Bearer " + voterToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(voteBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));

        // Second vote attempt by the same voter must be rejected.
        mockMvc.perform(post("/api/votes")
                        .header("Authorization", "Bearer " + voterToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(voteBody))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.success").value(false));
    }

    @Test
    void nonAdminCannotAccessAdminEndpoints() throws Exception {
        String voterToken = registerAndLogin("Voter Four", "voter4@example.com", "SecurePass1");

        mockMvc.perform(get("/api/admin/votes")
                        .header("Authorization", "Bearer " + voterToken))
                .andExpect(status().isForbidden());
    }

    @Test
    void adminCanExportExcelResults() throws Exception {
        String adminToken = loginAsAdmin();
        addCandidateAsAdmin(adminToken, "Candidate D", "Party D");

        mockMvc.perform(get("/api/admin/export/excel")
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isOk());
    }
}

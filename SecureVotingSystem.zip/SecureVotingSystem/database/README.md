# Database Setup

This project uses **MySQL 8+**.

## Option A — Let Spring Boot create everything (easiest)

1. Create an empty database:
   ```sql
   CREATE DATABASE secure_voting_db;
   ```
2. Set your MySQL username/password in
   `backend/src/main/resources/application.properties` (or as the
   `DB_USERNAME` / `DB_PASSWORD` environment variables).
3. Start the app. Hibernate (`spring.jpa.hibernate.ddl-auto=update`)
   creates the `users`, `candidates`, and `votes` tables automatically,
   and `DataInitializer` seeds a default admin account on first run.
4. Optionally run `data.sql` below to add sample candidates.

## Option B — Run the SQL scripts manually (recommended for a clean setup)

```bash
mysql -u root -p < schema.sql
mysql -u root -p < data.sql
```

This creates the database, all three tables (with the primary keys,
foreign keys, unique constraints, and indexes described in
`schema.sql`), and inserts four sample candidates.

## Tables

| Table        | Purpose                                              |
|--------------|-------------------------------------------------------|
| `users`      | Voters and admins. Passwords are stored as BCrypt hashes only. |
| `candidates` | Election candidates.                                  |
| `votes`      | One row per cast vote. A `UNIQUE` constraint on `voter_id` guarantees, at the database level, that a voter can never cast more than one vote. |

## Default admin account

Created automatically by the app on first startup:

- Email: `admin@voting.local` (or `ADMIN_EMAIL` env var)
- Password: `Admin@123` (or `ADMIN_PASSWORD` env var)

**Change this password immediately after your first login.**

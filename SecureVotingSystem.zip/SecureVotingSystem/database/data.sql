-- ============================================================
-- Sample seed data
-- ============================================================
-- The initial ROLE_ADMIN account is created automatically by the
-- Spring Boot application on first startup (see
-- com.example.voting.config.DataInitializer), using a securely
-- BCrypt-hashed password - so no admin row is inserted here.
--
-- IMPORTANT: change the default admin password immediately after
-- your first login. Configure it via the ADMIN_PASSWORD
-- environment variable before first run instead of using the
-- built-in default in a real deployment.
-- ============================================================

USE secure_voting_db;

INSERT INTO candidates (name, party, symbol, description) VALUES
    ('Arun Kumar',   'Progress Alliance',  'Lotus',   'Focused on education and youth employment.'),
    ('Divya Shree',  'Unity Front',        'Star',    'Focused on healthcare and rural development.'),
    ('Karthik Raja', 'Green Party',        'Tree',    'Focused on environment and sustainable energy.'),
    ('Meena Iyer',   'Peoples Coalition',  'Sun',     'Focused on infrastructure and public transport.');

-- ============================================================
-- Secure Voting System - Database Schema (MySQL 8+)
-- ============================================================
-- NOTE: The Spring Boot app can also auto-create/update these
-- tables on startup (spring.jpa.hibernate.ddl-auto=update), so
-- running this script manually is OPTIONAL but recommended for
-- a clean, predictable first setup.
-- ============================================================

CREATE DATABASE IF NOT EXISTS secure_voting_db
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE secure_voting_db;

-- ------------------------------------------------------------
-- users: voters and admins.
-- password_hash stores a BCrypt hash only - never plain text.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(120)  NOT NULL,
    email           VARCHAR(150)  NOT NULL,
    password_hash   VARCHAR(255)  NOT NULL,
    role            VARCHAR(20)   NOT NULL,
    has_voted       BOOLEAN       NOT NULL DEFAULT FALSE,
    created_at      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_users_email UNIQUE (email),
    CONSTRAINT chk_users_role CHECK (role IN ('ROLE_VOTER', 'ROLE_ADMIN'))
) ENGINE=InnoDB;

CREATE INDEX idx_users_email ON users (email);

-- ------------------------------------------------------------
-- candidates
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS candidates (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(120)  NOT NULL,
    party        VARCHAR(120)  NOT NULL,
    symbol       VARCHAR(255),
    description  VARCHAR(500)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- votes: one row per cast vote.
-- uk_voter_single_vote is the database-level guarantee that a
-- voter can never have more than one row here, even under
-- concurrent duplicate-vote attempts.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS votes (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    voter_id      BIGINT    NOT NULL,
    candidate_id  BIGINT    NOT NULL,
    voted_at      DATETIME  NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_voter_single_vote UNIQUE (voter_id),
    CONSTRAINT fk_votes_voter FOREIGN KEY (voter_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_votes_candidate FOREIGN KEY (candidate_id) REFERENCES candidates (id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_votes_candidate_id ON votes (candidate_id);

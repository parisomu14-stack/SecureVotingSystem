let editModal = null;

document.addEventListener("DOMContentLoaded", async () => {
    if (!requireLogin("ROLE_ADMIN")) return;
    setupLogoutButton();
    editModal = new bootstrap.Modal(document.getElementById("editModal"));

    await loadCandidates();
});

async function loadCandidates() {
    const alertBox = document.getElementById("alertBox");
    hideAlert(alertBox);

    const { ok, body } = await apiFetch("/api/candidates");
    if (!ok) {
        showAlert(alertBox, body.message || "Could not load candidates.");
        return;
    }
    const candidates = body.data;

    const resultsResp = await apiFetch("/api/results");
    const voteCounts = {};
    let totalVotes = 0;
    if (resultsResp.ok) {
        resultsResp.body.data.forEach(r => {
            voteCounts[r.candidateId] = r.totalVotes;
            totalVotes += r.totalVotes;
        });
    }

    document.getElementById("statCandidates").textContent = candidates.length;
    document.getElementById("statVotes").textContent = totalVotes;

    const tbody = document.getElementById("candidateTableBody");
    if (!candidates.length) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No candidates yet.</td></tr>';
        return;
    }

    tbody.innerHTML = candidates.map(c => `
        <tr>
            <td>${escapeHtml(c.name)}</td>
            <td>${escapeHtml(c.party)}</td>
            <td>${escapeHtml(c.symbol || "—")}</td>
            <td>${voteCounts[c.id] ?? 0}</td>
            <td>
                <button class="btn btn-sm btn-outline-primary edit-btn"
                        data-id="${c.id}" data-name="${escapeHtml(c.name)}"
                        data-party="${escapeHtml(c.party)}" data-symbol="${escapeHtml(c.symbol || "")}"
                        data-description="${escapeHtml(c.description || "")}">Edit</button>
                <button class="btn btn-sm btn-outline-danger delete-btn" data-id="${c.id}">Delete</button>
            </td>
        </tr>
    `).join("");

    document.querySelectorAll(".edit-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.getElementById("editId").value = btn.dataset.id;
            document.getElementById("editName").value = btn.dataset.name;
            document.getElementById("editParty").value = btn.dataset.party;
            document.getElementById("editSymbol").value = btn.dataset.symbol;
            document.getElementById("editDescription").value = btn.dataset.description;
            editModal.show();
        });
    });

    document.querySelectorAll(".delete-btn").forEach(btn => {
        btn.addEventListener("click", async () => {
            if (!confirm("Delete this candidate? This cannot be undone.")) return;
            const { ok, body } = await apiFetch("/api/admin/candidates/" + btn.dataset.id, { method: "DELETE" });
            if (ok) {
                await loadCandidates();
            } else {
                showAlert(document.getElementById("alertBox"), body.message || "Could not delete candidate.");
            }
        });
    });
}

document.getElementById("candidateForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const alertBox = document.getElementById("alertBox");

    const payload = {
        name: document.getElementById("candName").value.trim(),
        party: document.getElementById("candParty").value.trim(),
        symbol: document.getElementById("candSymbol").value.trim(),
        description: document.getElementById("candDescription").value.trim(),
    };

    const { ok, body } = await apiFetch("/api/admin/candidates", {
        method: "POST",
        body: JSON.stringify(payload),
    });

    if (ok) {
        e.target.reset();
        await loadCandidates();
    } else {
        showAlert(alertBox, body.message || "Could not add candidate.");
    }
});

document.getElementById("saveEditBtn").addEventListener("click", async () => {
    const id = document.getElementById("editId").value;
    const payload = {
        name: document.getElementById("editName").value.trim(),
        party: document.getElementById("editParty").value.trim(),
        symbol: document.getElementById("editSymbol").value.trim(),
        description: document.getElementById("editDescription").value.trim(),
    };

    const { ok, body } = await apiFetch("/api/admin/candidates/" + id, {
        method: "PUT",
        body: JSON.stringify(payload),
    });

    if (ok) {
        editModal.hide();
        await loadCandidates();
    } else {
        showAlert(document.getElementById("alertBox"), body.message || "Could not update candidate.");
    }
});

document.getElementById("exportBtn").addEventListener("click", async () => {
    const token = getToken();
    try {
        const response = await fetch("/api/admin/export/excel", {
            headers: { Authorization: "Bearer " + token },
        });
        if (!response.ok) {
            showAlert(document.getElementById("alertBox"), "Could not export results.");
            return;
        }
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "voting_results.xlsx";
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
    } catch (e) {
        showAlert(document.getElementById("alertBox"), "Export failed. Check the server logs.");
    }
});

function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
}

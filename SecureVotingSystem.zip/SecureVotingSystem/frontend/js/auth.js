// ============================================================
// Register page
// ============================================================
const registerForm = document.getElementById("registerForm");
if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const alertBox = document.getElementById("alertBox");
        const submitBtn = document.getElementById("submitBtn");
        hideAlert(alertBox);

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;
        const confirmPassword = document.getElementById("confirmPassword").value;

        if (password !== confirmPassword) {
            showAlert(alertBox, "Passwords do not match.");
            return;
        }

        submitBtn.disabled = true;
        submitBtn.textContent = "Registering...";

        const { ok, body } = await apiFetch("/api/auth/register", {
            method: "POST",
            body: JSON.stringify({ name, email, password, confirmPassword }),
        });

        submitBtn.disabled = false;
        submitBtn.textContent = "Register";

        if (ok && body.success) {
            saveSession(body.data);
            redirectAfterLogin(body.data.role);
        } else {
            const detail = body.data ? Object.values(body.data).join(" ") : "";
            showAlert(alertBox, (body.message || "Registration failed.") + " " + detail);
        }
    });
}

// ============================================================
// Login page
// ============================================================
const loginForm = document.getElementById("loginForm");
if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const alertBox = document.getElementById("alertBox");
        const submitBtn = document.getElementById("submitBtn");
        hideAlert(alertBox);

        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;

        submitBtn.disabled = true;
        submitBtn.textContent = "Logging in...";

        const { ok, body } = await apiFetch("/api/auth/login", {
            method: "POST",
            body: JSON.stringify({ email, password }),
        });

        submitBtn.disabled = false;
        submitBtn.textContent = "Login";

        if (ok && body.success) {
            saveSession(body.data);
            redirectAfterLogin(body.data.role);
        } else {
            showAlert(alertBox, body.message || "Login failed.");
        }
    });
}

// ============================================================
// Shared helpers used by every page (auth.js, vote.js, result.js, admin.js)
// ============================================================
const API_BASE = ""; // same origin - frontend is served by the Spring Boot backend

function saveSession(data) {
    localStorage.setItem("token", data.token);
    localStorage.setItem("userId", data.userId);
    localStorage.setItem("name", data.name);
    localStorage.setItem("email", data.email);
    localStorage.setItem("role", data.role);
    localStorage.setItem("hasVoted", data.hasVoted);
}

function getToken() {
    return localStorage.getItem("token");
}

function getRole() {
    return localStorage.getItem("role");
}

function getName() {
    return localStorage.getItem("name");
}

function clearSession() {
    localStorage.clear();
}

function requireLogin(expectedRole) {
    const token = getToken();
    if (!token) {
        window.location.href = "login.html";
        return false;
    }
    if (expectedRole && getRole() !== expectedRole) {
        window.location.href = "login.html";
        return false;
    }
    return true;
}

function redirectAfterLogin(role) {
    if (role === "ROLE_ADMIN") {
        window.location.href = "admin.html";
    } else {
        window.location.href = "vote.html";
    }
}

async function apiFetch(path, options = {}) {
    const token = getToken();
    const headers = Object.assign({ "Content-Type": "application/json" }, options.headers || {});
    if (token) {
        headers["Authorization"] = "Bearer " + token;
    }
    const response = await fetch(API_BASE + path, Object.assign({}, options, { headers }));

    if (response.status === 401) {
        // Expired/invalid JWT - force re-login.
        clearSession();
        window.location.href = "login.html";
        return { status: 401, ok: false, body: { success: false, message: "Session expired." } };
    }

    let body;
    try {
        body = await response.json();
    } catch (e) {
        body = { success: false, message: "Unexpected server response." };
    }

    return { status: response.status, ok: response.ok, body };
}

function showAlert(box, message, type = "danger") {
    if (!box) return;
    box.className = "alert alert-" + type;
    box.textContent = message;
    box.classList.remove("d-none");
}

function hideAlert(box) {
    if (!box) return;
    box.classList.add("d-none");
}

function setupLogoutButton() {
    const btn = document.getElementById("logoutBtn");
    if (btn) {
        btn.addEventListener("click", () => {
            clearSession();
            window.location.href = "login.html";
        });
    }
}

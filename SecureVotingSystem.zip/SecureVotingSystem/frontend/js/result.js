document.addEventListener("DOMContentLoaded", loadResults);

async function loadResults() {
    const alertBox = document.getElementById("alertBox");
    const tbody = document.getElementById("resultsBody");

    const { ok, body } = await apiFetch("/api/results");
    if (!ok) {
        showAlert(alertBox, body.message || "Could not load results.");
        return;
    }

    const results = body.data;
    if (!results.length) {
        tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No results yet.</td></tr>';
        return;
    }

    tbody.innerHTML = results.map(r => `
        <tr>
            <td>${escapeHtml(r.candidateName)}</td>
            <td>${escapeHtml(r.party)}</td>
            <td><strong>${r.totalVotes}</strong></td>
        </tr>
    `).join("");
}

function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
}

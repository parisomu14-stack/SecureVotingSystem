let selectedCandidate = null;
let confirmModal = null;

document.addEventListener("DOMContentLoaded", async () => {
    if (!requireLogin()) return;
    setupLogoutButton();

    document.getElementById("userNameLabel").textContent = "Hi, " + (getName() || "Voter");
    confirmModal = new bootstrap.Modal(document.getElementById("confirmModal"));

    const alertBox = document.getElementById("alertBox");

    // Check whether this voter has already voted before showing candidates.
    const statusResp = await apiFetch("/api/votes/status");
    if (!statusResp.ok) {
        showAlert(alertBox, statusResp.body.message || "Could not load vote status.");
        return;
    }

    if (statusResp.body.data.hasVoted) {
        document.getElementById("alreadyVotedBox").classList.remove("d-none");
        return;
    }

    await loadCandidates();
});

async function loadCandidates() {
    const alertBox = document.getElementById("alertBox");
    const grid = document.getElementById("candidateGrid");

    const { ok, body } = await apiFetch("/api/candidates");
    if (!ok) {
        showAlert(alertBox, body.message || "Could not load candidates.");
        return;
    }

    const candidates = body.data;
    if (!candidates.length) {
        grid.innerHTML = '<p class="text-center text-muted">No candidates have been added yet.</p>';
        return;
    }

    grid.innerHTML = candidates.map(c => `
        <div class="col-md-6 col-lg-3">
            <div class="card candidate-card h-100 shadow-sm text-center p-3">
                <h5 class="mt-2">${escapeHtml(c.name)}</h5>
                <p class="text-muted mb-1">${escapeHtml(c.party)}</p>
                <span class="badge bg-secondary symbol-badge mb-2">${escapeHtml(c.symbol || "—")}</span>
                <p class="small text-muted">${escapeHtml(c.description || "")}</p>
                <button class="btn btn-primary mt-auto vote-btn" data-id="${c.id}" data-name="${escapeHtml(c.name)}">
                    Vote
                </button>
            </div>
        </div>
    `).join("");

    document.querySelectorAll(".vote-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            selectedCandidate = { id: btn.dataset.id, name: btn.dataset.name };
            document.getElementById("confirmCandidateName").textContent = selectedCandidate.name;
            confirmModal.show();
        });
    });
}

document.getElementById("confirmVoteBtn").addEventListener("click", async () => {
    if (!selectedCandidate) return;
    const alertBox = document.getElementById("alertBox");
    const confirmBtn = document.getElementById("confirmVoteBtn");

    confirmBtn.disabled = true;
    confirmBtn.textContent = "Submitting...";

    const { ok, body } = await apiFetch("/api/votes", {
        method: "POST",
        body: JSON.stringify({ candidateId: Number(selectedCandidate.id) }),
    });

    confirmBtn.disabled = false;
    confirmBtn.textContent = "Yes, Cast My Vote";
    confirmModal.hide();

    if (ok && body.success) {
        localStorage.setItem("hasVoted", "true");
        document.getElementById("candidateGrid").innerHTML = "";
        showAlert(alertBox, "✅ Your vote has been recorded successfully. Thank you for voting!", "success");
        document.getElementById("alreadyVotedBox").classList.remove("d-none");
    } else {
        showAlert(alertBox, body.message || "Could not cast your vote.");
    }
});

function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
}

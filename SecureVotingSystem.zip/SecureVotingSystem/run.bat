@echo off
REM ============================================================
REM Secure Voting System - Windows launcher
REM ============================================================

echo ============================================================
echo  Secure Voting System - Starting up
echo ============================================================

where java >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: Java was not found on your PATH.
    echo Install Java 17+ from https://adoptium.net/ and try again.
    pause
    exit /b 1
)

where mvn >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: Maven was not found on your PATH.
    echo Install Maven from https://maven.apache.org/download.cgi and try again.
    pause
    exit /b 1
)

echo.
echo Have you already created the MySQL database and configured
echo backend\src\main\resources\application.properties (or the
echo DB_USERNAME / DB_PASSWORD environment variables)?
echo See the root README.md if not.
echo.

cd /d "%~dp0backend"
echo Building and starting the backend (this also copies the frontend
echo into the backend so it is served automatically)...
call mvn spring-boot:run

pause

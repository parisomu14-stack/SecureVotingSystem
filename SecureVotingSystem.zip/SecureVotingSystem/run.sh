#!/usr/bin/env bash
# ============================================================
# Secure Voting System - Linux/macOS launcher
# ============================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"

echo "============================================================"
echo " Secure Voting System - Starting up"
echo "============================================================"

if ! command -v java >/dev/null 2>&1; then
    echo "ERROR: Java was not found on your PATH."
    echo "Install Java 17+ from https://adoptium.net/ and try again."
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | head -n 1 | sed -E 's/.*"([0-9]+).*/\1/')
if [ "$JAVA_VERSION" -lt 17 ] 2>/dev/null; then
    echo "WARNING: Detected Java version $JAVA_VERSION. Java 17+ is required."
fi

if ! command -v mvn >/dev/null 2>&1; then
    echo "ERROR: Maven was not found on your PATH."
    echo "Install Maven from https://maven.apache.org/download.cgi and try again."
    exit 1
fi

echo
echo "Have you already created the MySQL database and configured"
echo "backend/src/main/resources/application.properties (or the"
echo "DB_USERNAME / DB_PASSWORD environment variables)?"
echo "See the root README.md if not."
echo

cd "$BACKEND_DIR"
echo "Building and starting the backend (this also copies the frontend"
echo "into the backend so it is served automatically)..."
mvn spring-boot:run
